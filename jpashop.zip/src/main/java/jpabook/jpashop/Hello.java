package jpabook.jpashop;

import lombok.Data;

@Data
public class Hello {
    private String data;
}
